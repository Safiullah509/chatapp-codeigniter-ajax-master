<p align="center">
  <h2 align="center">
    SELAMAT DATANG DI APLIKASI POST CHAT INDONESIA <br />
    SILAHKAN LOGIN TERLEBIH DAHULU SEBELUM <br />
    MENJALANKAN APLIKASI INI <br />
  </h2>
</p>