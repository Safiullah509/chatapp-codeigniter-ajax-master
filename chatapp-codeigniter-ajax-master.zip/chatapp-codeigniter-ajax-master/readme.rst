###################
ChatApp CodeIgniter Ajax
###################

This is an application which I develop back then during college, back then the purpose is to help friend creating a javascript setInterval-based chat application.
Nowadays a chat technology mostly use socket (i.e: socket.io), but this one can be used as basic understanding on how chatapp works without using any npm library.
There is a lot of messy code within controllers, views, even models. A lot of my friend still asked me about this repo even though there is a lot of better simple chat app out there.
Based on that reason, this app will be developed into a very basic one so even my friend can understand about how it works.
